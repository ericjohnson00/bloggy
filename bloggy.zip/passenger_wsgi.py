import os
import sys

# Add your application directory to the Python path
INTERP = os.path.expanduser("/home/USERNAME/virtualenv/YOUR_APP_DIRECTORY/3.9/bin/python")
if sys.executable != INTERP:
    os.execl(INTERP, INTERP, *sys.argv)

sys.path.append(os.getcwd())

from app import app as application